#!/usr/bin/python
import ast
import sys
from collections import defaultdict

class Label():
    def __init__(self, labelString):
        labels={'bot':0,'med':1,'top':2}
	if not labels.has_key(labelString): raise TypeError #TODO
        self.label=labelString
        self.I=labels

    def __repr__(self):
	return str(self.label)

    @property
    def toI(self):
	return self.I[self.label]
	
    def __le__(a,b):
	return a.toI <= b.toI

    def __add__(a,b):
	# TODO rewrite in terms of integers (or maybe sets?)
        if a.label is 'top' or b.label is 'top': return top
        else: return bot

bot=Label('bot')
top=Label('top')

class Value(object):
    def __init__(self,value='undefValue',label=bot,typel=bot):
        if   type(value) is int  :
		self.type='number'
        	self.value=value
        	self.label=label
        	self.typel=typel
        elif type(value) is bool :
		self.type='boolean'
        	self.value=value
        	self.label=label
        	self.typel=typel
        elif type(value) is str:
                if value is 'undefValue':
                     self.type='undef'
        	     self.value='undef'
                else :
                     self.type='string'
        	     self.value=value
        	self.label=label
        	self.typel=typel
        elif isinstance(value,Record):
		self.type='record'
		self.value=value
        	self.label=label
        	self.typel=typel
        elif isinstance(value,Value):
		self.type=value.type
		self.value=value.value
		self.label=value.label+label
        	self.typel=value.typel+typel
        else: print 'What is this?',type(value)

    @property
    def json(self):
        if self.type is 'record': return (self.value.json,str(self.label),self.type,str(self.typel))
	return (str(self.value),str(self.label),self.type,str(self.typel))

    @property
    def jsonJustValueInfo(self):
	return (str(self.value),str(self.label))

    @property
    def label(self):
        return self._label

    @label.setter
    def label(self,l):
        if ( self.type == 'record'):
	   self.value.E.setNewFactory(lambda: Value(value=False,label=l,typel=l))
	   self.value.V.setNewFactory(lambda: Value(label=l,typel=l))
	self._label=l

    def __repr__(self):
        return '< %s , %s >' % (self.value,self.label)

class PC(object):
    def __init__(self,l):
	if not isinstance(l,Label): raise Exception
        self._pc = [l]

    @property
    def pop(self):
        return self._pc.pop()

    def push(self, l):
	if not isinstance(l,Label): raise Exception
        self._pc.append(l+self.top)
        return self._pc

    @property
    def top(self):
        return self._pc[-1]

class Record():
    def __init__(self,monitor):
        self.E = liftedMap(lambda: Value(value=False),monitor)
        self.V = liftedMap(lambda: Value(),monitor)

    @property
    def json(self):
        return dict([ (k, (v.json , e.jsonJustValueInfo) ) for ((k,v),(ke,e)) in zip(self.V.items(),self.E.items()) ])

    def __repr__(self):
        return str([ '%s : %s - %s' % (k,v,e) for ((k,v),(ke,e)) in zip(self.V.items(),self.E.items()) ])

class SecurityException(Exception):
        def __init__(self): self.msg = "Security Violation"
        def __str__(self): return "Security Violation"

class liftedMap(defaultdict):
    def __init__(self,bottomElementFactory,monitor):
	self.monitor=monitor
        self.default_factory=bottomElementFactory
        
    def MUpdate(self,target,v,pc): #Generic MUpdate
        w=self[target]
	if pc <= w.label and pc <= w.typel:
             v.label += pc
             v.typel += pc
             self[target]=v
	     return  # allowed by NSU and VS
        else:
	    if self.monitor == 'VS':
		if w.value == v.value: return #allowed by VS. touch nothing
		if pc <= w.label and w.type==v.type : # update the value but not the type, since does not change
             	     v.label += pc
             	     self[target]=v
		     return
	raise SecurityException()

    def setNewFactory(self,factory):
        self.default_factory=factory

    def setLabel(self,var,label):
        self[var].label+=Label(label)

    @property
    def json(self):
	return dict((key, value.json) for (key, value) in self.items())

    def __repr__(self):
        return str([ i for i in self.items() ])

class ValueSensitivityMonitor(ast.NodeVisitor):
    def __init__(self,monitor):
	self.monitor= monitor
	self.status = "success"
	super(ValueSensitivityMonitor, self).__init__()

    def visit_Module(self, node):
        self.S = liftedMap(lambda: Value(),self.monitor)
        self.pc = PC(bot)
        self.generic_visit(node)

    def visit_Call(self, node):
        if type(node.func) is ast.Name and node.func.id.lower() == "type": 
	    if len(node.args) != 1: raise SyntaxError("type() needs one (and only one) argument.")
            v = self.visit(node.args[0])
	    return Value(v.type,label=v.typel)

        if type(node.func) is ast.Name and node.func.id is "labelValue": 
            self.S.setLabel(*[i.id for i in node.args])
	    return

    def visit_For(self, node): # For(expr target, expr iter, stmt* body, stmt* orelse)
	iter=self.visit(node.iter)

        if iter.type != 'record':
	   raise SyntaxError("The for loop needs a record to iterate.")

	iteration=0
        for k in iter.value.V:
           try:
                self.S.MUpdate(node.target.id,Value(k),self.pc.top+iter.label)
	   except SecurityException as e:
		e.offset=node.col_offset
		e.lineno=node.lineno
		raise e
	   self.pc.push(iter.label)
	   for n in node.body : self.visit(n)
	   self.pc.pop

	   iteration+=1
	   if iteration == 1000:
		e = StopIteration()
		e.msg = "This is a toy language, iterate more than 1000 times is not 'practical' here."
		e.lineno = node.lineno
		e.offset = node.col_offset
		raise e

    def visit_While(self, node): # While(expr test, stmt* body, stmt* orelse)
	v = self.visit(node.test)

        if v.value != True and v.value != False:
	   raise SyntaxError("The guard is not a boolean")

	iteration=0
        while v.value:
	   self.pc.push(v.label)
	   for n in node.body : self.visit(n)
	   self.pc.pop
	   v = self.visit(node.test)
	   iteration+=1
	   if iteration == 1000:
		e = StopIteration()
		e.msg = "This is a toy language, iterate more than 1000 times is not 'practical' here."
		e.lineno = node.lineno
		e.offset = node.col_offset
		raise e

    def visit_If(self, node): #If(expr test, stmt* body, stmt* orelse)
	v = self.visit(node.test)

        if v.value != True and v.value != False:
	   raise TypeError("The guard is not a boolean") 

	self.pc.push(v.label)
        if v.value:
	   for n in node.body : self.visit(n)
        else: 
	   for n in node.orelse : self.visit(n)
	self.pc.pop

    def visit_Dict(self, node):
        values=[ self.visit(i) for i in  node.values ]
        keys=[ self.visit(i) for i in node.keys]
        r = Record(self.monitor)
        valueTrue=Value(True)
        for (value,key) in zip(values,keys):
             sigma = self.pc.top + key.label
	     try:
               r.E.MUpdate(key.value, valueTrue,sigma)
               r.V.MUpdate(key.value, value,sigma)
	     except SecurityException as e:
		e.offset=node.col_offset
		e.lineno=node.lineno
		raise e
        return Value(r)
	
    def visit_Compare(self, node): # Compare(expr left, cmpop* ops, expr* comparators)

	# TODO multi comparision x < 4 < 3 and (x < 4) < 3
	if len(node.comparators) < 1 or len(node.ops) < 1: 
            raise SyntaxError("I can just compare two things, for now") 
	right = self.visit(node.comparators[0])
	op=type(node.ops[0])

	left=self.visit(node.left)
        l = left.label + right.label
        t = left.typel + right.typel

	# Eq | NotEq | Lt | LtE | Gt | GtE | Is | IsNot | In | NotIn
	if op == ast.Eq: return Value(left.value == right.value,l,t) 
	if op == ast.NotEq: return Value(left.value != right.value,l,t) 
	if op == ast.Lt: return Value(left.value < right.value,l,t) 
	if op == ast.LtE: return Value(left.value <= right.value,l,t) 
	if op == ast.Gt: return Value(left.value > right.value,l,t) 
	if op == ast.GtE: return Value(left.value >= right.value,l,t) 
	if op == ast.In or op == ast.NotIn:
	     if right.type == 'record':
	        r=Value(right.value.E[left.value])
                if op == ast.NotIn: r.value = not r.value
		r.label += left.label
	        return r
	     else : raise SyntaxError("the operator %s needs a record on the right hand" % op) 
	else:
            raise SyntaxError("the operator %s is not supported yet" % op)  # Is | IsNot

    def visit_Name(self, node):
        if node.id.lower() == 'true': return Value(True)
        if node.id.lower() == 'false': return Value(False)
        if node.id.lower() == 'undef': return Value("undefValue")

        return self.S[node.id]

    def visit_UnaryOp(self, node): # UnaryOp(unaryop op, expr operand)
	o = self.visit(node.operand)
	v = o.value
	l = o.label
	t = o.typel

	# Invert (a = ~3) | Not | UAdd (++3) | USub (--2)
        if type(node.op) is ast.Not : return Value(not v,l,t) 

   	e=SyntaxError("The UnaryOp operator %s is not part of this toy language" % type(node.op).__name__)
	e.offset=node.col_offset
	e.lineno=node.lineno
	raise e

    def visit_BinOp(self, node):
        left  = self.visit(node.left) 

	# | (BitOr) is used for labeling types and values
	# ^ (BitXor) is used for labeling just values
        if type(node.op) in (ast.BitXor,ast.BitOr): 
            if type(node.right) == ast.Name: 
               left.label = Label(node.right.id)
               if type(node.op) is ast.BitOr: left.typel = Label(node.right.id)
               return left
	    else: pass #TODO make sure right side is a label
        
	# & (BitAnd) is used for labeleing the existence of record field
        if type(node.op) is ast.BitAnd: 
            if type(node.right) == ast.Name and left.type == 'record':
		for i in left.value.V.values() : i.typel = Label(node.right.id)
		for i in left.value.V.values() : i.label = Label(node.right.id)
		for i in left.value.E.values() : i.label = Label(node.right.id)
		for i in left.value.E.values() : i.typel = Label(node.right.id)
                return left
	    else: pass #TODO make sure right side is a label
        
        right = self.visit(node.right) 
        l = left.label + right.label
        t = left.typel + right.typel

	# Add | Sub | Mult | Div | Mod | Pow | FloorDiv
        if type(node.op) is ast.Add : return Value(left.value + right.value,l,t) 
        if type(node.op) is ast.Sub : return Value(left.value - right.value,l,t) 
        if type(node.op) is ast.Mult : return Value(left.value * right.value,l,t) 
        if type(node.op) is ast.Pow : return Value(left.value ** right.value,l,t) 
        if type(node.op) is ast.Mod : return Value(left.value % right.value,l,t) 
        if type(node.op) is ast.FloorDiv : return Value(left.value // right.value,l,t) 

	# RShift | BitOr | LShift | BitAnd 
	e=SyntaxError("The arithmetic operator %s is not part of this toy language" % type(node.op).__name__)
	e.offset=node.col_offset
	e.lineno=node.lineno
	raise e

    def visit_Num(self, node):
        return Value(node.n)

    def visit_BoolOp(self, node):
        left  = self.visit(node.values[0])  
        right = self.visit(node.values[1])
        l = left.label + right.label
        t = left.typel + right.typel

        if type(node.op) is ast.And : return Value(left.value and right.value,l,t)
        if type(node.op) is ast.Or : return Value(left.value or right.value,l,t)

    def visit_Str(self, node):
        return Value(node.s)

    def projectField(self, recordprojection):  # Subscript(expr value, slice slice, expr_context ctx)
        try:
           f = self.visit(recordprojection.slice.value)
           r = self.S[recordprojection.value.id]
        except: raise SyntaxError("They way that you refer to a record element is funny")
        return (r,f)

    def visit_Delete(self, node):
        for target in node.targets:
            if type(target) is ast.Name :
		try:
                   self.S.MUpdate(target.id,Value(),self.pc.top)
	        except SecurityException as e:
	   	   e.offset=node.col_offset
	   	   e.lineno=node.lineno
		   raise e
            elif type(target) is ast.Subscript:
		(r,f) = self.projectField(target)
		try:
		  # sigma = pc \lub f.label
		  r.value.E.MUpdate(f.value,Value(  False,bot),self.pc.top + f.label)  #E[f.value]=Value(True)
		  r.value.V.MUpdate(f.value,Value('undefValue',bot),self.pc.top + f.label)  # V[f.value]=v
		except SecurityException as e:
		   e.offset=node.col_offset
		   e.lineno=node.lineno
		   raise e
            else: raise SyntaxError("You cannot assign to that") #TODO a proper raise exception

    def visit_Assign(self, node):
        v=self.visit(node.value)
        for target in node.targets:
            if type(target) is ast.Name :
		try:
                   self.S.MUpdate(target.id,v,self.pc.top)
		except SecurityException as e:
		   e.offset=node.col_offset
		   e.lineno=node.lineno
		   raise e
            elif type(target) is ast.Subscript:
		(r,f) = self.projectField(target)
		try:
		  # sigma = pc \lub f.label
		  r.value.E.MUpdate(f.value,Value(True),self.pc.top + f.label)  #E[f.value]=Value(True)
		  r.value.V.MUpdate(f.value,v,self.pc.top + f.label)  # V[f.value]=v
		except SecurityException as e:
		   e.offset=node.col_offset
		   e.lineno=node.lineno
		   raise e
            else: raise SyntaxError("You cannot assign to that") #TODO a proper raise exception

    def visit_Subscript(self, node): # Subscript(expr value, slice slice, expr_context ctx)
        (r,f)=self.projectField(node)
	return Value(r.value.V[f.value],f.label)

UnsupportedNodes = [
'Attribute',
'AugAssign',
'Break',
'ClassDef',
'Continue',
'DictComp',
'Exec',
'ExtSlice',
'FunctionDef',
'GeneratorExp',
'Global',
'Import',
'ImportFrom',
'Lambda',
'List',
'ListComp',
'Pass',
'Print',
'Raise',
'Return',
'Set',
'SetComp',
'Slice',
'Tuple',
'With',
'Yield']

def visit_generator(node):
    def visit_n(self,n):
        raise SyntaxError("%s is not part of this toy language" % node)
    return visit_n

for n in UnsupportedNodes:
    setattr(ValueSensitivityMonitor, 'visit_%s' % n, visit_generator(n) )

def run(source,monitor,outformat="web"):
    result={}
    try:
      code=ast.parse(source)
      visitor=ValueSensitivityMonitor(monitor)
      visitor.visit(code)
    except (IndentationError,SyntaxError,StopIteration) as e:
      return {"type":"error",
              "error":e.__class__.__name__,
              "message": e.msg,
              "line": e.lineno,
              "offset": e.offset,
             }
    except SecurityException as e:
      result={"type":"securityError",
              "error":e.__class__.__name__,
              "message": e.msg,
              "line": e.lineno,
              "offset": e.offset,
             }

    if not result.has_key("type"): result.update({'type':visitor.status})

    if outformat == "web":
         result.update({'S':visitor.S.json,'monitor':visitor.monitor})
    else:
         result.update({'S':visitor.S})
    return result

if __name__ == "__main__":
    from optparse import OptionParser
    parser = OptionParser()
    parser.add_option("-n", "--nsu", action="store_true", dest="NSU", default=False, help="Runs NSU without VS")
    (options, args)=parser.parse_args()

    monitor = 'VS'
    if options.NSU : monitor = 'NSU'
    source=open(args[0]).read()

    print run(source,monitor,"cli")
    #import json
    #print json.dumps(run(source,monitor).json, indent=4, separators=(',', ': '))
