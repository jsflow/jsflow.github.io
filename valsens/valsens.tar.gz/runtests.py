#!/usr/bin/python2.7
import unittest
from interpreter import run


class TestSequense(unittest.TestCase):
    pass

def test_generator(code, expects,monitor,status):
    def test(self):
	result=run(code,monitor,"test")
	self.assertEqual(str(result["type"]),status)
	if expects: self.assertEqual(str(result["S"]),expects)

    return test

if __name__ == '__main__':
    import yaml
    f = open('tests.yaml')
    
    for name,test in yaml.safe_load(f).iteritems():
	monitorNSU=True
	monitorVS =True

	if test.setdefault("monitor","both") == "NSU": monitorVS =False
	if test.setdefault("monitor","both") == "VS" : monitorNSU=False

	if monitorVS :
           test_name = 'test_%s_VS' % name
           setattr(TestSequense, test_name, test_generator(test["code"], test.setdefault("result",None),'VS',test.setdefault("status","success") ))

	if monitorNSU :
           test_name = 'test_%s_NSU' % name
           setattr(TestSequense, test_name, test_generator(test["code"], test.setdefault("result",None),'NSU',test.setdefault("status","success") ))
    f.close()
    unittest.main()
