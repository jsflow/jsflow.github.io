var express    = require('express')
  , cors       = require('cors')
  , bodyparser = require('body-parser');
  
// app

var app = express();
app.set('port', (process.env.PORT || 4777));
app.use(cors());
app.use(bodyparser.urlencoded({
  extended : false
}));

app.post('/paste', function(req, res) {
  console.log(req.body);
  res.end();

});

app.use(express.static(__dirname + '/public'));

app.listen(app.get('port'), function() {
  console.log('Node app is running on port', app.get('port'));
});


